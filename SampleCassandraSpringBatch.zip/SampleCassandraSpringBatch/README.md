# Spring batch with Cassandra config.

- **Custom ItemReader and ItemWriter.**
- **Work in a Batch to perform migration**
   
