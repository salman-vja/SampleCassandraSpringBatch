package com.sample.inv.SampleCassandraSpringBatch.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.repeat.CompletionPolicy;
import org.springframework.batch.repeat.policy.CompositeCompletionPolicy;
import org.springframework.batch.repeat.policy.SimpleCompletionPolicy;
import org.springframework.batch.repeat.policy.TimeoutTerminationPolicy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.dao.DeadlockLoserDataAccessException;
import org.springframework.data.cassandra.config.AbstractCassandraConfiguration;
import org.springframework.data.cassandra.config.CqlSessionFactoryBean;
import org.springframework.data.cassandra.config.SchemaAction;
import org.springframework.data.cassandra.core.CassandraTemplate;

import com.sample.inv.SampleCassandraSpringBatch.Jsonreader.SampleCassandraBatchJsonProcessor;
import com.sample.inv.SampleCassandraSpringBatch.Jsonreader.SampleCassandraBatchJsonWriter;
import com.sample.inv.SampleCassandraSpringBatch.Jsonreader.SampleCassandraBatchLocationJsonProcessor;
import com.sample.inv.SampleCassandraSpringBatch.Jsonreader.SampleCassandraBatchLocationJsonWriter;
import com.sample.inv.SampleCassandraSpringBatch.Jsonreader.model.Delivery;
import com.sample.inv.SampleCassandraSpringBatch.Jsonreader.model.Location;
import com.sample.inv.SampleCassandraSpringBatch.Jsonreader.model.Order;
import com.sample.inv.SampleCassandraSpringBatch.Jsonreader.reader.SampleCassandraBatchJsonReader;
import com.sample.inv.SampleCassandraSpringBatch.Jsonreader.reader.SampleCassandraBatchLocationJsonReader;
import com.sample.inv.SampleCassandraSpringBatch.tasks.JobCompletionNotificationListener;
import com.sample.inv.SampleCassandraSpringBatch.tasks.SampleCassandraDataPersist;
import com.sample.inv.SampleCassandraSpringBatch.tasks.SampleCassandraReadTask;

import io.netty.channel.ConnectTimeoutException;

@Configuration
@EnableBatchProcessing
public class JobConfiguration extends AbstractCassandraConfiguration {
	
	private static final Logger LOG = LoggerFactory.getLogger(this.class);

	@Autowired	
	public JobBuilderFactory jobBuilderFactory;

	@Autowired
	public StepBuilderFactory stepBuilderFactory;


	/*@Bean
	public SampleCassandraBatchJsonReader itemReader() {
		SampleCassandraBatchJsonReader reader = new SampleCassandraBatchJsonReader();
		reader.setClassToBound("com.sample.inv.SampleCassandraSpringBatch.Jsonreader.dto.RouteDto");
		reader.setResource(new ClassPathResource("/routes_view.json"));
		return reader;
	}
	
	
	@Bean
	public SampleCassandraBatchLocationJsonReader  itemLocationReader() {
		SampleCassandraBatchLocationJsonReader reader = new SampleCassandraBatchLocationJsonReader();
		reader.setResource(new ClassPathResource("/location.json"));
		return reader;
	}
	

	@Bean
	public SampleCassandraBatchJsonProcessor itemProcessor() {
		return new SampleCassandraBatchJsonProcessor();
	}
	
	@Bean
	public SampleCassandraBatchLocationJsonProcessor itemLocationProcessor() {
		return new SampleCassandraBatchLocationJsonProcessor();
	}
	
	@Bean
	public SampleCassandraBatchJsonWriter itemWriter() {
		return new SampleCassandraBatchJsonWriter();
	}
	
	@Bean
	public SampleCassandraBatchLocationJsonWriter itemLocationWriter() {
		return new SampleCassandraBatchLocationJsonWriter();
	}

	@SuppressWarnings("unchecked")
	@Bean
	public Step routeStep() {
		return stepBuilderFactory.get("routeStep").chunk(enhanceCompletionPolicy())
				.reader(itemReader()).processor(itemProcessor())
				.writer(itemWriter())
				.faultTolerant()
				.retryLimit(3)
				.retry(DeadlockLoserDataAccessException.class)
				.retry(ConnectTimeoutException.class).build();
	}

	@SuppressWarnings("unchecked")
	@Bean
	public Step locStep() {
		return stepBuilderFactory.get("locStep").chunk(enhanceCompletionPolicy())
				.reader(itemLocationReader()).processor(itemLocationProcessor())
				.writer(itemLocationWriter())
				.faultTolerant()
				.retryLimit(3)
				.retry(DeadlockLoserDataAccessException.class)
				.retry(ConnectTimeoutException.class).build();
	}
	
	@Bean	
	public Job SampleCassandraJsonReaderJob() throws Exception {
		return jobBuilderFactory.get("SampleCassandraJsonReaderJob")
				.start(locStep()).next(routeStep()).build();
	}*/
	
	@Override
	protected String getKeyspaceName() {
		return "inventory";
	}
	
    @Override
    public SchemaAction getSchemaAction() {
        return SchemaAction.NONE;
    }
    
    @Override
    public String[] getEntityBasePackages() {
        return new String[] {Order.class.getPackage().getName(),Delivery.class.getPackage().getName(),Location.class.getName()};
    }
  
	private CqlSessionFactoryBean Session() {
		CqlSessionFactoryBean bean = new CqlSessionFactoryBean();
		bean.setContactPoints("127.0.0.1");
		bean.setLocalDatacenter(getLocalDataCenter());
		bean.setKeyspaceName(getKeyspaceName());
		bean.setPort(9042);
		bean.afterPropertiesSet();
		return bean;
	}
	
	@Bean(name = "cassandraTemplate")
    public CassandraTemplate profileCassandraTemplate() throws Exception {
        final CassandraTemplate cassandraTemplate = new CassandraTemplate(Session().getObject(), cassandraConverter());
        LOG.info("Created Cassandra template {} ", cassandraTemplate);
        return cassandraTemplate;
    }

	
    @Bean
    public Step SampleCassandraReadStep(){
        return stepBuilderFactory.get("SampleCassandraReadStep")
                .tasklet(new SampleCassandraReadTask()).build();
    }

    @Bean
    public Step SampleCassandraPersistStep() throws Exception{
        return stepBuilderFactory.get("SampleCassandraPersistStep")
                .tasklet(new SampleCassandraDataPersist(profileCassandraTemplate()))
                .build();
    }
    @Bean
    public JobExecutionListener listener() throws Exception {
    	return new JobCompletionNotificationListener(profileCassandraTemplate());
    }
 

   @Bean
   public Job SampleCassandraApiJob() throws Exception{
        return jobBuilderFactory.get("SampleCassandraJob")
                .start(SampleCassandraReadStep())
                .next(SampleCassandraPersistStep()).listener(listener())
                .build();
    }

    

    private CompositeCompletionPolicy enhanceCompletionPolicy(){
            CompositeCompletionPolicy completionPolicy = new CompositeCompletionPolicy();
			CompletionPolicy [] policies = new CompletionPolicy[2];
			policies[0] = new SimpleCompletionPolicy(5);
			policies[1] = new TimeoutTerminationPolicy(60*1000);
			completionPolicy.setPolicies(policies);
			return completionPolicy;
    }
    




}
