package com.sample.inv.SampleCassandraSpringBatch.tasks;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.cassandra.core.CassandraTemplate;

import static com.sample.inv.SampleCassandraSpringBatch.tasks.constants.TaskConstants.CREATED_BY;
import com.sample.inv.SampleCassandraSpringBatch.Jsonreader.dto.LocationDataDto;
import com.sample.inv.SampleCassandraSpringBatch.Jsonreader.dto.RouteDataDto;
import com.sample.inv.SampleCassandraSpringBatch.Jsonreader.model.Delivery;
import com.sample.inv.SampleCassandraSpringBatch.Jsonreader.model.Location;
import com.sample.inv.SampleCassandraSpringBatch.Jsonreader.model.Order;

public class SampleCassandraDataPersist implements Tasklet, StepExecutionListener {

	private List<RouteDataDto> todayRouteEntity;
	
	private List<RouteDataDto> tomorrowRouteEntity;

	private List<LocationDataDto> locationDataEntityList;

	private CassandraTemplate cassandraTemplate;
	
	

	@Autowired
	public SampleCassandraDataPersist(final CassandraTemplate cassandraTemplate) {
		this.cassandraTemplate = cassandraTemplate;
	}

	private static final Logger LOGGER = LoggerFactory.getLogger(this.class);

	@SuppressWarnings("unchecked")
	public void beforeStep(StepExecution stepExecution) {
		this.locationDataEntityList = (List<LocationDataDto>) stepExecution.getJobExecution().getExecutionContext().get("OMSLocationData");
		this.todayRouteEntity = (List<RouteDataDto>) stepExecution.getJobExecution().getExecutionContext().get("OMSRouteData");
		this.tomorrowRouteEntity = (List<RouteDataDto>) stepExecution.getJobExecution().getExecutionContext().get("OMSTomorrowRouteData");

	}

	public ExitStatus afterStep(StepExecution stepExecution) {
		return null;
	}

	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

		
		for (LocationDataDto locationEnity : locationDataEntityList) {
			Location location = new Location();
			BeanUtils.copyProperties(locationEnity, location);
			cassandraTemplate.insert(location);
		}
		
		persistRoutes(this.todayRouteEntity);	
		persistRoutes(this.tomorrowRouteEntity);
	
		return RepeatStatus.FINISHED;
	}
	 
	private void persistRoutes(List<RouteDataDto> routeList) {
		if(!routeList.isEmpty()) {
			for (RouteDataDto route : routeList) {
				Order orderdto = new Order();
				Delivery deliverydto = new Delivery();

				BeanUtils.copyProperties(route, deliverydto);
				setDeliveryCommonFields(deliverydto);
				cassandraTemplate.insert(deliverydto);
				
				BeanUtils.copyProperties(route, orderdto);
				setOrderCommonFields(route,orderdto);
				if(cassandraTemplate.exists(route.getDeliveryId(), Order.class)) {
					cassandraTemplate.update(orderdto);
				}else {
					orderdto.setOrderSequenceId(generateUniqueId());
					cassandraTemplate.insert(orderdto);
				}
				
			}

		}
		else {
			LOGGER.info("No Routes found");
		}	
		
	}
	
	
	private void setDeliveryCommonFields(Delivery deliveryDto) {
		deliveryDto.setCreatedBy(CREATED_BY);
		deliveryDto.setCreatedDateTime(Timestamp.valueOf(LocalDateTime.now().withNano(0)));
		deliveryDto.setLastUpdatedBy(CREATED_BY);
		deliveryDto.setLastUpdatedTimeStamp(Timestamp.valueOf(LocalDateTime.now().withNano(0)));

	}
	
	private void setOrderCommonFields(RouteDataDto route,Order orderDto) {
		
		//orderDto.setSkuNo(route.getItem());
		//orderDto.setLastUpdatedTimeStamp(Timestamp.valueOf(LocalDateTime.now().withNano(0)));
		orderDto.setCreatedDateTime(Timestamp.valueOf(LocalDateTime.now().withNano(0)));
		orderDto.setCreatedBy(CREATED_BY);
		//orderDto.setLastUpdatedBy(CREATED_BY);

	}
	private Long generateUniqueId() {
        long val = -1;
        do {
            val = UUID.randomUUID().getMostSignificantBits();
        } while (val < 0);
        return val;
    }

}
