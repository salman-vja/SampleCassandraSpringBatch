 package com.sample.inv.SampleCassandraSpringBatch.Jsonreader;


import java.util.List;
import java.util.UUID;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.cassandra.core.CassandraTemplate;

import com.sample.inv.SampleCassandraSpringBatch.Jsonreader.dto.OrderDto;
import com.sample.inv.SampleCassandraSpringBatch.Jsonreader.model.Delivery;
import com.sample.inv.SampleCassandraSpringBatch.Jsonreader.model.Order;

public class SampleCassandraBatchJsonWriter implements ItemWriter<OrderDto> {

	
    @Autowired
    private CassandraTemplate cassandraTemplate;


	public void write(List<? extends OrderDto> items) throws Exception
	{
		for(OrderDto item: items) {
			Order orderdto=new Order();
			Delivery deliverydto=new Delivery();
			BeanUtils.copyProperties(item, orderdto);
			orderdto.setOrderSequenceId(generateUniqueId());
			orderdto.setShipmentNumber((orderdto.getShipmentNumber()==null)?("13FS0440"+Math.random()):orderdto.getShipmentNumber());
			cassandraTemplate.insert(orderdto);
			
			BeanUtils.copyProperties(item, deliverydto);
			cassandraTemplate.insert(deliverydto);
			
		}
	}
	private Long generateUniqueId() {
        long val = -1;
        do {
            val = UUID.randomUUID().getMostSignificantBits();
        } while (val < 0);
        return val;
    }




}
