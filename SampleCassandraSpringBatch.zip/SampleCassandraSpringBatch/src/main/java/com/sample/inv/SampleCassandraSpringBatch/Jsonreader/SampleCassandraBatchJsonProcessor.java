package com.sample.inv.SampleCassandraSpringBatch.Jsonreader;



import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.BeanUtils;

import com.sample.inv.SampleCassandraSpringBatch.Jsonreader.dto.OrderDto;
import com.sample.inv.SampleCassandraSpringBatch.Jsonreader.dto.RouteDataDto;

public class SampleCassandraBatchJsonProcessor implements ItemProcessor<RouteDataDto,OrderDto>{
	
	public OrderDto process(final RouteDataDto item) throws Exception
	{
			final OrderDto createdOrder=new OrderDto();
			BeanUtils.copyProperties(item, createdOrder);
			return createdOrder		;
	}



}
