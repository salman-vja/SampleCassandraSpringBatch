package com.sample.inv.SampleCassandraSpringBatch.Jsonreader.model;

import java.sql.Timestamp;
import java.util.Date;

import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("T_Order")
public class Order {

	
	@PrimaryKeyColumn(name = "ORDER_SEQ_ID", ordinal = 1, type =PrimaryKeyType.PARTITIONED )
	public Long OrderSequenceId;
	
	//@Column("BatchRouteSeq") //t
	@Column("BATCH_ROUTE_SEQ") 
	public String batchRouteSeq;

	/*@Column("StartTime")
	public String startTime;

	@Column("EndTime")
	public String endTime;
	
	@Column("Duration")
	public String duration;

	@Column("RouteMileage")
	public String routeMileage;

	@Column("StopSeq")
	public String stopSeq;

	@Column("StopNumber")
	public int stopNumber;

	@Column("EstimatedArrival")
	public String estimatedArrival;

	@Column("EstimatedTime")
	public String estimatedTime;

	@Column("Latitude")
	public String latitude;

	@Column("Longitude")
	public String longitude;

	@Column("StopMileage")
	public String stopMileage;

	@Column("AutoTimeframeStart")
	public String autoTimeFrameStart;

	@Column("AutoTimeframeEnd")
	public String autoTimeFrameEnd;

	@Column("EditTimeframeStart")
	public String editTimeFrameStart;

	@Column("EditTimeframeEnd")
	public String editTimeFrameEnd;

	@Column("StopStatus")
	public String stopStatus;*/

	//@Column("DeliverySeq")  //t
	@Column("DELIVERY_SEQ")  //t
	public String deliverySeq;

	@Column("ChannelSeq")
	public String channelSeq;

	//@Column("RouteFlag")  //t
	@Column("ROUTE_FLAG")  //t
	public String routeFlag;

	/*@Column("PrecallFlag")
	public String precallFlag;

	@Column("PrecallStatus")
	public String precallStatus;

	@Column("PrecallContactNumber")
	public String precallContactNumber;

	@Column("PrecallContactDatetime")
	public String precallContactDatetime;*/

	
	@Column("CUST_SALES_ORDER") //t
	public String custSalesOrder;

	
	@Column("ORDER_TYPE") //t
	public String orderType;

	
	@Column("ORDER_DATE") 
	public Date orderDate;

	
	@PrimaryKeyColumn(name = "DELIVERY_ID", ordinal = 2, type =PrimaryKeyType.PARTITIONED )
	public String deliveryId;

	//@Column("ZipGroup")
	//public String zipGroup;

	//@Column("DeliveryDate") //t
	//@Column("DELIVERY_DATE") 
	//public Date deliveryDate;

	//@Column("DeliveryName") 
	//@Column("DELIVERY_NAME") 
	//public String deliveryName;
	
	
	//@Column("DeliveryAddress1")
	//public String deliveryAddress1;

	/*@Column("DeliveryAddress2")
	public String deliveryAddress2;

	@Column("DeliveryCity")
	public String deliveryCity;

	@Column("DeliveryState")
	public String deliveryState;

	@Column("DeliveryZip")
	public String deliveryZip;*/

	
	//@Column("DeliveryPhone1")
	//public String deliveryPhone1;
	
	/*@Column("DeliveryPhone2")
	public String deliveryPhone2;

	@Column("DeliveryPhone3")
	public String deliveryPhone3;

	@Column("DeliveryPhone4")
	public String deliveryPhone4;

	@Column("LastUpdatedDate")
	public String lastUpdatedDate;*/

	//@Column("CsoType") 
	@Column("CSO_TYPE") 
	public String csoType;

	//@Column("CustomerPoNumber") //t
	@Column("PURCHASE_ORDER") //t
	public String customerPoNumber;

	/*@Column("Rap")
	public String rap;

	@Column("OrderPoints")
	public String orderPoints;

	@Column("GeoStreet1")
	public String geoStreet1;

	@Column("GeoLatitude")
	public String geoLatitude;

	@Column("GeoLongitude")
	public String geoLongitude;*/

	//@Column("DeliveryItemSeq")
	@Column("DELIVERY_ITEM_SEQ")
	public String deliveryItemSeq;

	@Column("LINE_NO" )
	public String lineNumber;

	@Column("LINE_STATUS")
	public String lineStatus;

	/*@Column("CratedIndicator")
	public String cratedIndicator;*/

	//@Column("ItemType") //t
	@Column("ITEM_TYPE") 
	public String itemType;

	//@Column("Item")
	@Column("MODEL_NO")
	public String item;

	//@Column("ProductType")  //t
	@Column("PRODUCT_TYPE")  
	public String productType;

	//@Column("AntiTipIndicator")
	//public String antiTipIndicator;

	//@Column("ProductWeight")  //t
	@Column("PRODUCT_WEIGHT")  //t
	public String productWeight;

	/*@Column("Nmfc")
	public String nmfc;

	@Column("CartonCode")
	public String cartonCode;

	@Column("Quantity")
	public String quantity;

	@Column("Points")
	public String points;*/

	@Column("SERIAL_NO")
	public String assignedSerials;

	@Column("TRACKING_NO")
	public String customerTrackingNumber;

	//@Column("ItemVendor") //t
	@Column("ITEM_VENDOR") 
	public String itemVendor;

	//@Column("ItemShipdate") //t
	@Column("ITEM_SHIP_DATE") 
	public Date itemShipdate;

	//@Column("LocationSeq") //t
	@Column("LOCATION_SEQ") 
	public String locationSeq;

	//@Column("LocationCode") //t
	@Column("LOCATION_CODE") //t
	public String locationCode;

	/*@Column("GeCode")
	public String geCode;

	@Column("DaySeq")
	public String daySeq;

	@Column("DeliveryDay")
	public String deliveryDay;*/

	//@Column("RouteSeq") //t
	@Column("ROUTE_SEQ") //t
	public String routeSeq;

	//@Column("RouteName") //t
	@Column("ROUTE_NAME") //t
	public String routeName;

	//@Column("ShipmentSeq")  //t
	@Column("SHIPMENT_SEQ")  //t
	public String shipmentSeq;

	//@Column("Vendor")    //t
	@Column("VENDOR")   
	public String vendor;

	@Column("SHIPMENT_NUM")
	public String shipmentNumber;

	//@Column("ShipDate")     //t
	@Column("SHIP_DATE")     //t
	public Date shipDate;

	//@Column("ShipmentStatus")  //t
	@Column("SHIPMENT_STATUS")  //t
	public String shipmentStatus;

	//@Column("LstShipmentStatus")//t
	@Column("LST_SHIPMENT_STATUS")//t
	public String lstShipmentStatus;

	@Column("CHANNEL_CODE")
	public String channelCode;

	//@Column("DeliveryStatus") //t
	//@Column("DELIVERY_STATUS") 
	//public String deliveryStatus;

	/*@Column("ComboGroup")
	public String comboGroup;*/

	@Column("Description")
	public String description;

	/*@Column("EluxLotId")
	public String eluxLotId;*/
	
	@Column("CREATED_BY")
	public String createdBy;
	
	@Column("CREATED_ON")
	public Timestamp createdDateTime;
	
	/*@Column("LAST_UPDATEDBY")
	public String lastUpdatedBy;
	
	@Column("LAST_UPDATED_TIMESTAMP")
	public Timestamp lastUpdatedTimeStamp;
	
	@Column("RECEIVED")
	public String received;
	
	@Column("RECEIVED_QUALITY")
	public String receivedQuality;
	
	@Column("PUTAWAY_LOCATION")
	public String putawayLocation;
	
	@Column("SKU_NO")
	public String skuNo;
	
	@Column("ASN_NO")
	public String asnNo;
	
	@Column("ASN_STATUS")
	public String asnStatus;*/

	public Long getOrderSequenceId() {
		return OrderSequenceId;
	}
	
	public String getDeliveryId() {
		return deliveryId;
	}

	public void setDeliveryId(String deliveryId) {
		this.deliveryId = deliveryId;
	}

	public void setOrderSequenceId(Long orderSequenceId) {
		OrderSequenceId = orderSequenceId;
	}

	public String getBatchRouteSeq() {
		return batchRouteSeq;
	}

	public void setBatchRouteSeq(String batchRouteSeq) {
		this.batchRouteSeq = batchRouteSeq;
	}

	public String getDeliverySeq() {
		return deliverySeq;
	}

	public void setDeliverySeq(String deliverySeq) {
		this.deliverySeq = deliverySeq;
	}

	public String getChannelSeq() {
		return channelSeq;
	}

	public void setChannelSeq(String channelSeq) {
		this.channelSeq = channelSeq;
	}

	public String getRouteFlag() {
		return routeFlag;
	}

	public void setRouteFlag(String routeFlag) {
		this.routeFlag = routeFlag;
	}

	public String getCustSalesOrder() {
		return custSalesOrder;
	}

	public void setCustSalesOrder(String custSalesOrder) {
		this.custSalesOrder = custSalesOrder;
	}

	public String getOrderType() {
		return orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	public String getCsoType() {
		return csoType;
	}

	public void setCsoType(String csoType) {
		this.csoType = csoType;
	}

	public String getCustomerPoNumber() {
		return customerPoNumber;
	}

	public void setCustomerPoNumber(String customerPoNumber) {
		this.customerPoNumber = customerPoNumber;
	}

	public String getDeliveryItemSeq() {
		return deliveryItemSeq;
	}

	public void setDeliveryItemSeq(String deliveryItemSeq) {
		this.deliveryItemSeq = deliveryItemSeq;
	}

	public String getLineNumber() {
		return lineNumber;
	}

	public void setLineNumber(String lineNumber) {
		this.lineNumber = lineNumber;
	}

	public String getLineStatus() {
		return lineStatus;
	}

	public void setLineStatus(String lineStatus) {
		this.lineStatus = lineStatus;
	}

	public String getItemType() {
		return itemType;
	}

	public void setItemType(String itemType) {
		this.itemType = itemType;
	}

	public String getItem() {
		return item;
	}

	public void setItem(String item) {
		this.item = item;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public String getProductWeight() {
		return productWeight;
	}

	public void setProductWeight(String productWeight) {
		this.productWeight = productWeight;
	}

	public String getAssignedSerials() {
		return assignedSerials;
	}

	public void setAssignedSerials(String assignedSerials) {
		this.assignedSerials = assignedSerials;
	}

	public String getCustomerTrackingNumber() {
		return customerTrackingNumber;
	}

	public void setCustomerTrackingNumber(String customerTrackingNumber) {
		this.customerTrackingNumber = customerTrackingNumber;
	}

	public String getItemVendor() {
		return itemVendor;
	}

	public void setItemVendor(String itemVendor) {
		this.itemVendor = itemVendor;
	}

	public Date getItemShipdate() {
		return itemShipdate;
	}

	public void setItemShipdate(Date itemShipdate) {
		this.itemShipdate = itemShipdate;
	}

	public String getLocationSeq() {
		return locationSeq;
	}

	public void setLocationSeq(String locationSeq) {
		this.locationSeq = locationSeq;
	}

	public String getLocationCode() {
		return locationCode;
	}

	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}

	public String getRouteSeq() {
		return routeSeq;
	}

	public void setRouteSeq(String routeSeq) {
		this.routeSeq = routeSeq;
	}

	public String getRouteName() {
		return routeName;
	}

	public void setRouteName(String routeName) {
		this.routeName = routeName;
	}

	public String getShipmentSeq() {
		return shipmentSeq;
	}

	public void setShipmentSeq(String shipmentSeq) {
		this.shipmentSeq = shipmentSeq;
	}

	public String getVendor() {
		return vendor;
	}

	public void setVendor(String vendor) {
		this.vendor = vendor;
	}

	public String getShipmentNumber() {
		return shipmentNumber;
	}

	public void setShipmentNumber(String shipmentNumber) {
		this.shipmentNumber = shipmentNumber;
	}

	public Date getShipDate() {
		return shipDate;
	}

	public void setShipDate(Date shipDate) {
		this.shipDate = shipDate;
	}

	public String getShipmentStatus() {
		return shipmentStatus;
	}

	public void setShipmentStatus(String shipmentStatus) {
		this.shipmentStatus = shipmentStatus;
	}

	public String getLstShipmentStatus() {
		return lstShipmentStatus;
	}

	public void setLstShipmentStatus(String lstShipmentStatus) {
		this.lstShipmentStatus = lstShipmentStatus;
	}

	public String getChannelCode() {
		return channelCode;
	}

	public void setChannelCode(String channelCode) {
		this.channelCode = channelCode;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDateTime() {
		return createdDateTime;
	}

	public void setCreatedDateTime(Timestamp createdDateTime) {
		this.createdDateTime = createdDateTime;
	}
	

	/*public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Timestamp getLastUpdatedTimeStamp() {
		return lastUpdatedTimeStamp;
	}

	public void setLastUpdatedTimeStamp(Timestamp lastUpdatedTimeStamp) {
		this.lastUpdatedTimeStamp = lastUpdatedTimeStamp;
	}

	public String getReceived() {
		return received;
	}

	public void setReceived(String received) {
		this.received = received;
	}

	public String getReceivedQuality() {
		return receivedQuality;
	}

	public void setReceivedQuality(String receivedQuality) {
		this.receivedQuality = receivedQuality;
	}

	public String getPutawayLocation() {
		return putawayLocation;
	}

	public void setPutawayLocation(String putawayLocation) {
		this.putawayLocation = putawayLocation;
	}

	public String getSkuNo() {
		return skuNo;
	}

	public void setSkuNo(String skuNo) {
		this.skuNo = skuNo;
	}

	public String getAsnNo() {
		return asnNo;
	}

	public void setAsnNo(String asnNo) {
		this.asnNo = asnNo;
	}

	public String getAsnStatus() {
		return asnStatus;
	}

	public void setAsnStatus(String asnStatus) {
		this.asnStatus = asnStatus;
	}

	@Override
	public String toString() {
		return "Order [OrderSequenceId=" + OrderSequenceId + ", batchRouteSeq=" + batchRouteSeq + ", deliverySeq="
				+ deliverySeq + ", channelSeq=" + channelSeq + ", routeFlag=" + routeFlag + ", custSalesOrder="
				+ custSalesOrder + ", orderType=" + orderType + ", orderDate=" + orderDate + ", csoType=" + csoType
				+ ", customerPoNumber=" + customerPoNumber + ", deliveryItemSeq=" + deliveryItemSeq + ", lineNumber="
				+ lineNumber + ", lineStatus=" + lineStatus + ", itemType=" + itemType + ", item=" + item
				+ ", productType=" + productType + ", productWeight=" + productWeight + ", assignedSerials="
				+ assignedSerials + ", customerTrackingNumber=" + customerTrackingNumber + ", itemVendor=" + itemVendor
				+ ", itemShipdate=" + itemShipdate + ", locationSeq=" + locationSeq + ", locationCode=" + locationCode
				+ ", routeSeq=" + routeSeq + ", routeName=" + routeName + ", shipmentSeq=" + shipmentSeq + ", vendor="
				+ vendor + ", shipmentNumber=" + shipmentNumber + ", shipDate=" + shipDate + ", shipmentStatus="
				+ shipmentStatus + ", lstShipmentStatus=" + lstShipmentStatus + ", channelCode=" + channelCode
				+ ", description=" + description + ", createdBy=" + createdBy + ", createdDateTime=" + createdDateTime
				+ ", lastUpdatedBy=" + lastUpdatedBy + ", lastUpdatedTimeStamp=" + lastUpdatedTimeStamp + ", received="
				+ received + ", receivedQuality=" + receivedQuality + ", putawayLocation=" + putawayLocation
				+ ", skuNo=" + skuNo + ", asnNo=" + asnNo + ", asnStatus=" + asnStatus + "]";
	}*/
	
	

	
}
