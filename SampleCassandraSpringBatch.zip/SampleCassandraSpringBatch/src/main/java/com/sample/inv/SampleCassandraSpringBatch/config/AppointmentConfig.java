package com.sample.inv.SampleCassandraSpringBatch.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.cassandra.config.AbstractCassandraConfiguration;
import org.springframework.data.cassandra.config.CqlSessionFactoryBean;
import org.springframework.data.cassandra.config.SchemaAction;
import org.springframework.data.cassandra.core.CassandraTemplate;

import com.sample.inv.SampleCassandraSpringBatch.Jsonreader.model.Order;

@Configuration
public class AppointmentConfig extends AbstractCassandraConfiguration {

	private static final Logger LOG = LoggerFactory.getLogger(this.class);

	@Value("${spring.data.cassandra.appointment.keyspace-name}")
	private String KEY_SPACE;

	@Primary
	@Bean(name = "appointmentTemplate")
	public CassandraTemplate profileCassandraTemplate() throws Exception {
		final CassandraTemplate cassandraTemplate = new CassandraTemplate(session().getObject(), cassandraConverter());
		LOG.info("Mapped Keyspace to appointment session {} ", session().getObject().getKeyspace());
		LOG.info("Created Cassandra appointmentTemplate {} ", cassandraTemplate);
		LOG.info("Created Cassandra template mapped table {} ", cassandraTemplate.getTableName(Order.class));
		return cassandraTemplate;
	}

	@Override
	protected int getPort() {
		return 9042;
	}

	@Override
	public SchemaAction getSchemaAction() {
		return SchemaAction.CREATE_IF_NOT_EXISTS;
	}

	@Override
	protected String getKeyspaceName() {
		return KEY_SPACE;
	}

	@Override
	public String[] getEntityBasePackages() {
		return new String[] { Order.class.getPackage().getName() };
	}

	@Primary
	@Bean
	public CqlSessionFactoryBean session() throws Exception {

		CqlSessionFactoryBean session = new CqlSessionFactoryBean();
		session.setContactPoints(getContactPoints());
		session.setLocalDatacenter(getLocalDataCenter());
		session.setKeyspaceName(getKeyspaceName());
		session.setPort(getPort());
		session.afterPropertiesSet();

		return session;
	}

}
