package com.sample.inv.SampleCassandraSpringBatch.Jsonreader.model;

import java.sql.Timestamp;

import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("T_Delivery")
public class Delivery {
	
	@PrimaryKey("DELIVERY_ID") 
	public String deliveryId;
	
	@Column("DELIVERY_DATE") 
	public String deliveryDate;

	@Column("DELIVERY_NAME") 
	public String deliveryName;
	
	@Column("DELIVERY_SEQ")  //t
	public String deliverySeq;
	
	@Column("DELIVERY_STATUS") 
	public String deliveryStatus;

	@Column("DELIVERY_ADDRESS1")
	public String deliveryAddress1;

	@Column("DELIVERY_ADDRESS2")
	public String deliveryAddress2;

	@Column("DELIVERY_CITY")
	public String deliveryCity;

	@Column("DELIVERY_STATE")
	public String deliveryState;

	@Column("DELIVERY_ZIP")
	public String deliveryZip;

	@Column("DELIVERY_PHONE1")
	public String deliveryPhone1;

	@Column("DELIVERY_PHONE2")
	public String deliveryPhone2;
	
	@Column("CREATED_BY")
	public String createdBy;
	
	@Column("CREATED_DATETIME")
	public Timestamp createdDateTime;
	
	@Column("LAST_UPDATEDBY")
	public String lastUpdatedBy;
	
	@Column("LAST_UPDATED_TIMESTAMP")
	public Timestamp lastUpdatedTimeStamp;

	public String getDeliveryId() {
		return deliveryId;
	}

	public void setDeliveryId(String deliveryId) {
		this.deliveryId = deliveryId;
	}

	public String getDeliveryDate() {
		return deliveryDate;
	}

	public void setDeliveryDate(String deliveryDate) {
		this.deliveryDate = deliveryDate;
	}

	public String getDeliveryName() {
		return deliveryName;
	}

	public void setDeliveryName(String deliveryName) {
		this.deliveryName = deliveryName;
	}

	public String getDeliveryAddress1() {
		return deliveryAddress1;
	}

	public void setDeliveryAddress1(String deliveryAddress1) {
		this.deliveryAddress1 = deliveryAddress1;
	}

	public String getDeliveryAddress2() {
		return deliveryAddress2;
	}

	public void setDeliveryAddress2(String deliveryAddress2) {
		this.deliveryAddress2 = deliveryAddress2;
	}

	public String getDeliveryCity() {
		return deliveryCity;
	}

	public void setDeliveryCity(String deliveryCity) {
		this.deliveryCity = deliveryCity;
	}

	public String getDeliveryState() {
		return deliveryState;
	}

	public void setDeliveryState(String deliveryState) {
		this.deliveryState = deliveryState;
	}

	public String getDeliveryZip() {
		return deliveryZip;
	}

	public void setDeliveryZip(String deliveryZip) {
		this.deliveryZip = deliveryZip;
	}

	public String getDeliveryPhone1() {
		return deliveryPhone1;
	}

	public void setDeliveryPhone1(String deliveryPhone1) {
		this.deliveryPhone1 = deliveryPhone1;
	}

	public String getDeliveryPhone2() {
		return deliveryPhone2;
	}

	public void setDeliveryPhone2(String deliveryPhone2) {
		this.deliveryPhone2 = deliveryPhone2;
	}
	
	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDateTime() {
		return createdDateTime;
	}

	public void setCreatedDateTime(Timestamp createdDateTime) {
		this.createdDateTime = createdDateTime;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Timestamp getLastUpdatedTimeStamp() {
		return lastUpdatedTimeStamp;
	}

	public void setLastUpdatedTimeStamp(Timestamp lastUpdatedTimeStamp) {
		this.lastUpdatedTimeStamp = lastUpdatedTimeStamp;
	}

	public String getDeliverySeq() {
		return deliverySeq;
	}

	public void setDeliverySeq(String deliverySeq) {
		this.deliverySeq = deliverySeq;
	}

	public String getDeliveryStatus() {
		return deliveryStatus;
	}

	public void setDeliveryStatus(String deliveryStatus) {
		this.deliveryStatus = deliveryStatus;
	}

	@Override
	public String toString() {
		return "Delivery [deliveryId=" + deliveryId + ", deliveryDate=" + deliveryDate + ", deliveryName="
				+ deliveryName + ", deliverySeq=" + deliverySeq + ", deliveryStatus=" + deliveryStatus
				+ ", deliveryAddress1=" + deliveryAddress1 + ", deliveryAddress2=" + deliveryAddress2
				+ ", deliveryCity=" + deliveryCity + ", deliveryState=" + deliveryState + ", deliveryZip=" + deliveryZip
				+ ", deliveryPhone1=" + deliveryPhone1 + ", deliveryPhone2=" + deliveryPhone2 + ", createdBy="
				+ createdBy + ", createdDateTime=" + createdDateTime + ", lastUpdatedBy=" + lastUpdatedBy
				+ ", lastUpdatedTimeStamp=" + lastUpdatedTimeStamp + "]";
	}
	
}
