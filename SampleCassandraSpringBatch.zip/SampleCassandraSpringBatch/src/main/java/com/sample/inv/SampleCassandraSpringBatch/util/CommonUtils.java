package com.sample.inv.SampleCassandraSpringBatch.util;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.springframework.util.StringUtils;

public class CommonUtils {
	
	
	public static LocalDate convertStringToDate(String str) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/YYYY HH:mm:ss");
	
	    if(!StringUtils.isEmpty(str)) 
			return LocalDate.parse(str, formatter);
		else 
			return LocalDate.parse(LocalDate.now().toString(),formatter);
	}
	
	public static LocalDateTime convertStringToTimeStamp(String str) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/YYYY'T'HH:mm:ss");
		
		if(!StringUtils.isEmpty(str) && str.contains(Character.toString('T'))) 
			return LocalDateTime.parse(str, formatter);
		else 
			return LocalDateTime.now().withNano(0);
	}
	public static String convertDateToString(String date) {
		LocalDate givenDate = LocalDate.parse(date);
		return givenDate.toString(); 
	}
	public static String convertTimeStampToString(String timeStamp) {
		LocalDateTime givenTS = LocalDateTime.parse(timeStamp);
		return givenTS.toString(); 
	}
	
	
}
