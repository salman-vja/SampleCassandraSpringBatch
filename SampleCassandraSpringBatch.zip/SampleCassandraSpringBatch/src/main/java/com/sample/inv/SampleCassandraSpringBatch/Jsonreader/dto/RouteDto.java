 package com.sample.inv.SampleCassandraSpringBatch.Jsonreader.dto;


import org.codehaus.jackson.annotate.JsonProperty;

import java.io.Serializable;
import java.util.List;

public class RouteDto implements Serializable {

	private static final long serialVersionUID = -4768395625787010658L;

	@JsonProperty("ReturnCode")
	public String returnCode;

	@JsonProperty("data")
	 public List<RouteDataDto> data;

	public RouteDto() {
		super();
	}

	public RouteDto(String returnCode, List<RouteDataDto> data) {
		super();
		this.returnCode = returnCode;
		this.data = data;
	}

	public String getReturnCode()
	{
		return returnCode;
	}

	public void setReturnCode(String returnCode)
	{
		this.returnCode = returnCode;
	}

	public List<RouteDataDto> getData()
	{
		return data;
	}

	public void setData(List<RouteDataDto> data)
	{
		this.data = data;
	}

	@Override
	public String toString()
	{
		return "RouteEntity [returnCode=" + returnCode + ", data=" + data + "]";
	}






}
