 package com.sample.inv.SampleCassandraSpringBatch.Jsonreader.dto;

import java.io.Serializable;
import java.util.Date;

import org.codehaus.jackson.annotate.JsonProperty;

public class RouteDataDto implements Serializable{

	private static final long serialVersionUID = -3346161688443936146L;

	@JsonProperty("BatchRouteSeq")
	 public String batchRouteSeq;

	 @JsonProperty("StartTime")
	 public String startTime;

	 @JsonProperty("EndTime")
	 public String endTime;

	 @JsonProperty("Duration")
	 public String duration;

	 @JsonProperty("RouteMileage")
	 public String routeMileage;

	 @JsonProperty("StopSeq")
	 public String stopSeq;

	 @JsonProperty("StopNumber")
	 public int stopNumber;

	 @JsonProperty("EstimatedArrival")
	 public String estimatedArrival;

	 @JsonProperty("EstimatedTime")
	 public String estimatedTime;

	 @JsonProperty("Latitude")
	 public String latitude;

	 @JsonProperty("Longitude")
	 public String longitude;

	 @JsonProperty("StopMileage")
	 public String stopMileage;

	 @JsonProperty("AutoTimeframeStart")
	 public String autoTimeFrameStart;

	 @JsonProperty("AutoTimeframeEnd")
	 public String autoTimeFrameEnd;

	 @JsonProperty("EditTimeframeStart")
	 public String editTimeFrameStart;

	 @JsonProperty("EditTimeframeEnd")
	 public String editTimeFrameEnd;

	 @JsonProperty("StopStatus")
	 public String stopStatus;

	 @JsonProperty("DeliverySeq")
	 public String deliverySeq;

	 @JsonProperty("ChannelSeq")
     public String channelSeq;

	 @JsonProperty("RouteFlag")
     public String routeFlag;

	 @JsonProperty("PrecallFlag")
     public String precallFlag;

	 @JsonProperty("PrecallStatus")
     public String precallStatus;

	 @JsonProperty("PrecallContactNumber")
     public String precallContactNumber;

	 @JsonProperty("PrecallContactDatetime")
     public String precallContactDatetime;

	 @JsonProperty("CustSalesOrder")
     public String  custSalesOrder;

	 @JsonProperty("OrderType")
     public String orderType;

	 @JsonProperty("OrderDate")
     public Date orderDate;

	 @JsonProperty("DeliveryId")
     public String deliveryId;

	 @JsonProperty("ZipGroup")
     public String zipGroup;

	 @JsonProperty("DeliveryDate")
     public Date deliveryDate;

	 @JsonProperty("DeliveryName")
     public String deliveryName;

	 @JsonProperty("DeliveryAddress1")
     public String deliveryAddress1;

	 @JsonProperty("DeliveryAddress2")
     public String deliveryAddress2;

	 @JsonProperty("DeliveryCity")
     public String deliveryCity;

	 @JsonProperty("DeliveryState")
     public String deliveryState;

	 @JsonProperty("DeliveryZip")
     public String deliveryZip;

	 @JsonProperty("DeliveryPhone1")
     public String deliveryPhone1;

	 @JsonProperty("DeliveryPhone2")
     public String deliveryPhone2;

	 @JsonProperty("DeliveryPhone3")
     public String deliveryPhone3;

	 @JsonProperty("DeliveryPhone4")
     public String deliveryPhone4;

	 @JsonProperty("LastUpdatedDate")
     public String lastUpdatedDate;

	 @JsonProperty("CsoType")
     public String csoType;

	 @JsonProperty("CustomerPoNumber")
     public String customerPoNumber;

	 @JsonProperty("Rap")
     public String rap;

	 @JsonProperty("OrderPoints")
     public String orderPoints;

	 @JsonProperty("GeoStreet1")
     public String geoStreet1;

	 @JsonProperty("GeoLatitude")
     public String geoLatitude;

	 @JsonProperty("GeoLongitude")
     public String geoLongitude;

	 @JsonProperty("DeliveryItemSeq")
     public String deliveryItemSeq;

	 @JsonProperty("LineNumber")
     public String lineNumber;

	 @JsonProperty("LineStatus")
     public String lineStatus;

	 @JsonProperty("CratedIndicator")
     public String cratedIndicator;

	 @JsonProperty("ItemType")
     public String itemType;

	 @JsonProperty("Item")
     public String item;

	 @JsonProperty("ProductType")
     public String productType;

	 @JsonProperty("AntiTipIndicator")
     public String antiTipIndicator;

	 @JsonProperty("ProductWeight")
     public String productWeight;


	 @JsonProperty("Nmfc")
     public String nmfc;

	 @JsonProperty("CartonCode")
     public String cartonCode;

	 @JsonProperty("Quantity")
     public String quantity;

	 @JsonProperty("Points")
     public String points;

	 @JsonProperty("AssignedSerials")
     public String assignedSerials;

	 @JsonProperty("CustomerTrackingNumber")
     public String customerTrackingNumber;

	 @JsonProperty("ItemVendor")
     public String itemVendor;

	 @JsonProperty("ItemShipdate")
     public Date itemShipdate;

	 @JsonProperty("LocationSeq")
     public String locationSeq;

	 @JsonProperty("LocationCode")
     public String locationCode;

	 @JsonProperty("GeCode")
     public String geCode;

	 @JsonProperty("DaySeq")
     public String daySeq;

	 @JsonProperty("DeliveryDay")
     public String deliveryDay;

	 @JsonProperty("RouteSeq")
     public String routeSeq;

	 @JsonProperty("RouteName")
     public String routeName;

	 @JsonProperty("ShipmentSeq")
     public String shipmentSeq;

	 @JsonProperty("Vendor")
     public String vendor;

	 @JsonProperty("ShipmentNumber")
     public String shipmentNumber;

	 @JsonProperty("ShipDate")
     public Date shipDate;

	 @JsonProperty("ShipmentStatus")
     public String shipmentStatus;

	 @JsonProperty("LstShipmentStatus")
     public String lstShipmentStatus;

	 @JsonProperty("ChannelCode")
     public String channelCode;

	 @JsonProperty("DeliveryStatus")
     public String deliveryStatus;

	 @JsonProperty("ComboGroup")
     public String comboGroup;

	 @JsonProperty("Description")
     public String description;

	 @JsonProperty("EluxLotId")
     public String eluxLotId;




	public RouteDataDto() {
		super();
	}


	public String getBatchRouteSeq()
	{
		return batchRouteSeq;
	}
	public void setBatchRouteSeq(String batchRouteSeq)
	{
		this.batchRouteSeq = batchRouteSeq;
	}
	public String getStartTime()
	{
		return startTime;
	}
	public void setStartTime(String startTime)
	{
		this.startTime = startTime;
	}
	public String getEndTime()
	{
		return endTime;
	}
	public void setEndTime(String endTime)
	{
		this.endTime = endTime;
	}
	public String getDuration()
	{
		return duration;
	}
	public void setDuration(String duration)
	{
		this.duration = duration;
	}
	public String getRouteMileage()
	{
		return routeMileage;
	}
	public void setRouteMileage(String routeMileage)
	{
		this.routeMileage = routeMileage;
	}
	public String getStopSeq()
	{
		return stopSeq;
	}
	public void setStopSeq(String stopSeq)
	{
		this.stopSeq = stopSeq;
	}
	public int getStopNumber()
	{
		return stopNumber;
	}
	public void setStopNumber(int stopNumber)
	{
		this.stopNumber = stopNumber;
	}
	public String getEstimatedArrival()
	{
		return estimatedArrival;
	}
	public void setEstimatedArrival(String estimatedArrival)
	{
		this.estimatedArrival = estimatedArrival;
	}
	public String getEstimatedTime()
	{
		return estimatedTime;
	}
	public void setEstimatedTime(String estimatedTime)
	{
		this.estimatedTime = estimatedTime;
	}
	public String getLatitude()
	{
		return latitude;
	}
	public void setLatitude(String latitude)
	{
		this.latitude = latitude;
	}
	public String getLongitude()
	{
		return longitude;
	}
	public void setLongitude(String longitude)
	{
		this.longitude = longitude;
	}
	public String getStopMileage()
	{
		return stopMileage;
	}
	public void setStopMileage(String stopMileage)
	{
		this.stopMileage = stopMileage;
	}
	public String getAutoTimeFrameStart()
	{
		return autoTimeFrameStart;
	}
	public void setAutoTimeFrameStart(String autoTimeFrameStart)
	{
		this.autoTimeFrameStart = autoTimeFrameStart;
	}
	public String getAutoTimeFrameEnd()
	{
		return autoTimeFrameEnd;
	}
	public void setAutoTimeFrameEnd(String autoTimeFrameEnd)
	{
		this.autoTimeFrameEnd = autoTimeFrameEnd;
	}
	public String getEditTimeFrameStart()
	{
		return editTimeFrameStart;
	}
	public void setEditTimeFrameStart(String editTimeFrameStart)
	{
		this.editTimeFrameStart = editTimeFrameStart;
	}
	public String getEditTimeFrameEnd()
	{
		return editTimeFrameEnd;
	}
	public void setEditTimeFrameEnd(String editTimeFrameEnd)
	{
		this.editTimeFrameEnd = editTimeFrameEnd;
	}
	public String getStopStatus()
	{
		return stopStatus;
	}
	public void setStopStatus(String stopStatus)
	{
		this.stopStatus = stopStatus;
	}
	public String getDeliverySeq()
	{
		return deliverySeq;
	}
	public void setDeliverySeq(String deliverySeq)
	{
		this.deliverySeq = deliverySeq;
	}
	public String getChannelSeq()
	{
		return channelSeq;
	}
	public void setChannelSeq(String channelSeq)
	{
		this.channelSeq = channelSeq;
	}
	public String getRouteFlag()
	{
		return routeFlag;
	}
	public void setRouteFlag(String routeFlag)
	{
		this.routeFlag = routeFlag;
	}
	public String getPrecallFlag()
	{
		return precallFlag;
	}
	public void setPrecallFlag(String precallFlag)
	{
		this.precallFlag = precallFlag;
	}
	public String getPrecallStatus()
	{
		return precallStatus;
	}
	public void setPrecallStatus(String precallStatus)
	{
		this.precallStatus = precallStatus;
	}
	public String getPrecallContactNumber()
	{
		return precallContactNumber;
	}
	public void setPrecallContactNumber(String precallContactNumber)
	{
		this.precallContactNumber = precallContactNumber;
	}
	public String getPrecallContactDatetime()
	{
		return precallContactDatetime;
	}
	public void setPrecallContactDatetime(String precallContactDatetime)
	{
		this.precallContactDatetime = precallContactDatetime;
	}
	public String getCustSalesOrder()
	{
		return custSalesOrder;
	}
	public void setCustSalesOrder(String custSalesOrder)
	{
		this.custSalesOrder = custSalesOrder;
	}
	public String getOrderType()
	{
		return orderType;
	}
	public void setOrderType(String orderType)
	{
		this.orderType = orderType;
	}
	public Date getOrderDate()
	{
		return orderDate;
	}
	public void setOrderDate(Date orderDate)
	{
		this.orderDate = orderDate;
	}
	public String getDeliveryId()
	{
		return deliveryId;
	}
	public void setDeliveryId(String deliveryId)
	{
		this.deliveryId = deliveryId;
	}
	public String getZipGroup()
	{
		return zipGroup;
	}
	public void setZipGroup(String zipGroup)
	{
		this.zipGroup = zipGroup;
	}
	public Date getDeliveryDate()
	{
		return deliveryDate;
	}
	public void setDeliveryDate(Date deliveryDate)
	{
		this.deliveryDate = deliveryDate;
	}
	public String getDeliveryName()
	{
		return deliveryName;
	}
	public void setDeliveryName(String deliveryName)
	{
		this.deliveryName = deliveryName;
	}
	public String getDeliveryAddress1()
	{
		return deliveryAddress1;
	}
	public void setDeliveryAddress1(String deliveryAddress1)
	{
		this.deliveryAddress1 = deliveryAddress1;
	}
	public String getDeliveryAddress2()
	{
		return deliveryAddress2;
	}
	public void setDeliveryAddress2(String deliveryAddress2)
	{
		this.deliveryAddress2 = deliveryAddress2;
	}
	public String getDeliveryCity()
	{
		return deliveryCity;
	}
	public void setDeliveryCity(String deliveryCity)
	{
		this.deliveryCity = deliveryCity;
	}
	public String getDeliveryState()
	{
		return deliveryState;
	}
	public void setDeliveryState(String deliveryState)
	{
		this.deliveryState = deliveryState;
	}
	public String getDeliveryZip()
	{
		return deliveryZip;
	}
	public void setDeliveryZip(String deliveryZip)
	{
		this.deliveryZip = deliveryZip;
	}
	public String getDeliveryPhone1()
	{
		return deliveryPhone1;
	}
	public void setDeliveryPhone1(String deliveryPhone1)
	{
		this.deliveryPhone1 = deliveryPhone1;
	}
	public String getDeliveryPhone2()
	{
		return deliveryPhone2;
	}
	public void setDeliveryPhone2(String deliveryPhone2)
	{
		this.deliveryPhone2 = deliveryPhone2;
	}
	public String getDeliveryPhone3()
	{
		return deliveryPhone3;
	}
	public void setDeliveryPhone3(String deliveryPhone3)
	{
		this.deliveryPhone3 = deliveryPhone3;
	}
	public String getDeliveryPhone4()
	{
		return deliveryPhone4;
	}
	public void setDeliveryPhone4(String deliveryPhone4)
	{
		this.deliveryPhone4 = deliveryPhone4;
	}
	public String getLastUpdatedDate()
	{
		return lastUpdatedDate;
	}
	public void setLastUpdatedDate(String lastUpdatedDate)
	{
		this.lastUpdatedDate = lastUpdatedDate;
	}
	public String getCsoType()
	{
		return csoType;
	}
	public void setCsoType(String csoType)
	{
		this.csoType = csoType;
	}
	public String getCustomerPoNumber()
	{
		return customerPoNumber;
	}
	public void setCustomerPoNumber(String customerPoNumber)
	{
		this.customerPoNumber = customerPoNumber;
	}
	public String getRap()
	{
		return rap;
	}
	public void setRap(String rap)
	{
		this.rap = rap;
	}
	public String getOrderPoints()
	{
		return orderPoints;
	}
	public void setOrderPoints(String orderPoints)
	{
		this.orderPoints = orderPoints;
	}
	public String getGeoStreet1()
	{
		return geoStreet1;
	}
	public void setGeoStreet1(String geoStreet1)
	{
		this.geoStreet1 = geoStreet1;
	}
	public String getGeoLatitude()
	{
		return geoLatitude;
	}
	public void setGeoLatitude(String geoLatitude)
	{
		this.geoLatitude = geoLatitude;
	}
	public String getGeoLongitude()
	{
		return geoLongitude;
	}
	public void setGeoLongitude(String geoLongitude)
	{
		this.geoLongitude = geoLongitude;
	}
	public String getDeliveryItemSeq()
	{
		return deliveryItemSeq;
	}
	public void setDeliveryItemSeq(String deliveryItemSeq)
	{
		this.deliveryItemSeq = deliveryItemSeq;
	}
	public String getLineNumber()
	{
		return lineNumber;
	}
	public void setLineNumber(String lineNumber)
	{
		this.lineNumber = lineNumber;
	}
	public String getLineStatus()
	{
		return lineStatus;
	}
	public void setLineStatus(String lineStatus)
	{
		this.lineStatus = lineStatus;
	}
	public String getCratedIndicator()
	{
		return cratedIndicator;
	}
	public void setCratedIndicator(String cratedIndicator)
	{
		this.cratedIndicator = cratedIndicator;
	}
	public String getItemType()
	{
		return itemType;
	}
	public void setItemType(String itemType)
	{
		this.itemType = itemType;
	}
	public String getItem()
	{
		return item;
	}
	public void setItem(String item)
	{
		this.item = item;
	}
	public String getProductType()
	{
		return productType;
	}
	public void setProductType(String productType)
	{
		this.productType = productType;
	}
	public String getAntiTipIndicator()
	{
		return antiTipIndicator;
	}
	public void setAntiTipIndicator(String antiTipIndicator)
	{
		this.antiTipIndicator = antiTipIndicator;
	}
	public String getProductWeight()
	{
		return productWeight;
	}
	public void setProductWeight(String productWeight)
	{
		this.productWeight = productWeight;
	}
	public String getNmfc()
	{
		return nmfc;
	}
	public void setNmfc(String nmfc)
	{
		this.nmfc = nmfc;
	}
	public String getCartonCode()
	{
		return cartonCode;
	}
	public void setCartonCode(String cartonCode)
	{
		this.cartonCode = cartonCode;
	}
	public String getQuantity()
	{
		return quantity;
	}
	public void setQuantity(String quantity)
	{
		this.quantity = quantity;
	}
	public String getPoints()
	{
		return points;
	}
	public void setPoints(String points)
	{
		this.points = points;
	}
	public String getAssignedSerials()
	{
		return assignedSerials;
	}
	public void setAssignedSerials(String assignedSerials)
	{
		this.assignedSerials = assignedSerials;
	}
	public String getCustomerTrackingNumber()
	{
		return customerTrackingNumber;
	}
	public void setCustomerTrackingNumber(String customerTrackingNumber)
	{
		this.customerTrackingNumber = customerTrackingNumber;
	}
	public String getItemVendor()
	{
		return itemVendor;
	}
	public void setItemVendor(String itemVendor)
	{
		this.itemVendor = itemVendor;
	}
	public Date getItemShipdate()
	{
		return itemShipdate;
	}
	public void setItemShipdate(Date itemShipdate)
	{
		this.itemShipdate = itemShipdate;
	}
	public String getLocationSeq()
	{
		return locationSeq;
	}
	public void setLocationSeq(String locationSeq)
	{
		this.locationSeq = locationSeq;
	}
	public String getLocationCode()
	{
		return locationCode;
	}
	public void setLocationCode(String locationCode)
	{
		this.locationCode = locationCode;
	}
	public String getGeCode()
	{
		return geCode;
	}
	public void setGeCode(String geCode)
	{
		this.geCode = geCode;
	}
	public String getDaySeq()
	{
		return daySeq;
	}
	public void setDaySeq(String daySeq)
	{
		this.daySeq = daySeq;
	}
	public String getDeliveryDay()
	{
		return deliveryDay;
	}
	public void setDeliveryDay(String deliveryDay)
	{
		this.deliveryDay = deliveryDay;
	}
	public String getRouteSeq()
	{
		return routeSeq;
	}
	public void setRouteSeq(String routeSeq)
	{
		this.routeSeq = routeSeq;
	}
	public String getRouteName()
	{
		return routeName;
	}
	public void setRouteName(String routeName)
	{
		this.routeName = routeName;
	}
	public String getShipmentSeq()
	{
		return shipmentSeq;
	}
	public void setShipmentSeq(String shipmentSeq)
	{
		this.shipmentSeq = shipmentSeq;
	}
	public String getVendor()
	{
		return vendor;
	}
	public void setVendor(String vendor)
	{
		this.vendor = vendor;
	}
	public String getShipmentNumber()
	{
		return shipmentNumber;
	}
	public void setShipmentNumber(String shipmentNumber)
	{
		this.shipmentNumber = shipmentNumber;
	}
	public Date getShipDate()
	{
		return shipDate;
	}
	public void setShipDate(Date shipDate)
	{
		this.shipDate = shipDate;
	}
	public String getShipmentStatus()
	{
		return shipmentStatus;
	}
	public void setShipmentStatus(String shipmentStatus)
	{
		this.shipmentStatus = shipmentStatus;
	}
	public String getLstShipmentStatus()
	{
		return lstShipmentStatus;
	}
	public void setLstShipmentStatus(String lstShipmentStatus)
	{
		this.lstShipmentStatus = lstShipmentStatus;
	}
	public String getChannelCode()
	{
		return channelCode;
	}
	public void setChannelCode(String channelCode)
	{
		this.channelCode = channelCode;
	}
	public String getDeliveryStatus()
	{
		return deliveryStatus;
	}
	public void setDeliveryStatus(String deliveryStatus)
	{
		this.deliveryStatus = deliveryStatus;
	}
	public String getComboGroup()
	{
		return comboGroup;
	}
	public void setComboGroup(String comboGroup)
	{
		this.comboGroup = comboGroup;
	}
	public String getDescription()
	{
		return description;
	}
	public void setDescription(String description)
	{
		this.description = description;
	}
	public String getEluxLotId()
	{
		return eluxLotId;
	}
	public void setEluxLotId(String eluxLotId)
	{
		this.eluxLotId = eluxLotId;
	}



}
