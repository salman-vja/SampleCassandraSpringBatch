package com.sample.inv.SampleCassandraSpringBatch.Jsonreader.dto;



import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize
public class LocationDataDto implements Serializable{

	@JsonProperty("LocationSeq")
	private Long locationSeq;

	@JsonProperty("LocationCode")
	private String locationCode;

	@JsonProperty("GeCode")
	private String geCode;

	@JsonProperty("AcctCode")
	private String acctCode;

	@JsonProperty("City")
	private String city;

	@JsonProperty("State")
	private String state;

	@JsonProperty("Zipcode")
	private String zipcode;

	@JsonProperty("SeasonalMessage")
	private String seasonalMessage;

	@JsonProperty("Timezone")
	private String timezone;

	@JsonProperty("WindowLength")
	private String windowLength;

	@JsonProperty("Use30minWindow")
	private String use30minWindow;

	@JsonProperty("FirstWindowHour")
	private String firstWindowHour;

	@JsonProperty("LastWindowHour")
	private Integer lastWindowHour;

	@JsonProperty("PrecallCallerId")
	private Long precallCallerId;

	@JsonProperty("PrecallTransfer")
	private Long precallTransfer;

	@JsonProperty("ElectroluxLocation")
	private String electroluxLocation;

	@JsonProperty("WayfairLocation")
	private String wayfairLocation;

	@JsonProperty("FaltlLocation")
	private String faltlLocation;

	@JsonProperty("CreateDate")
	private String createDate;

	@JsonProperty("CreateBy")
	private String createBy;

	@JsonProperty("ModifyDate")
	private String modifyDate;

	@JsonProperty("ModifyBy")
	private String modifyBy;

	public LocationDataDto() {
		super();
	}

	public Long getLocationSeq() {
		return locationSeq;
	}

	public void setLocationSeq(Long locationSeq) {
		this.locationSeq = locationSeq;
	}

	public String getLocationCode() {
		return locationCode;
	}

	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}

	public String getGeCode() {
		return geCode;
	}

	public void setGeCode(String geCode) {
		this.geCode = geCode;
	}

	public String getAcctCode() {
		return acctCode;
	}

	public void setAcctCode(String acctCode) {
		this.acctCode = acctCode;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	public String getSeasonalMessage() {
		return seasonalMessage;
	}

	public void setSeasonalMessage(String seasonalMessage) {
		this.seasonalMessage = seasonalMessage;
	}

	public String getTimezone() {
		return timezone;
	}

	public void setTimezone(String timezone) {
		this.timezone = timezone;
	}

	public String getWindowLength() {
		return windowLength;
	}

	public void setWindowLength(String windowLength) {
		this.windowLength = windowLength;
	}

	public String getUse30minWindow() {
		return use30minWindow;
	}

	public void setUse30minWindow(String use30minWindow) {
		this.use30minWindow = use30minWindow;
	}

	public String getFirstWindowHour() {
		return firstWindowHour;
	}

	public void setFirstWindowHour(String firstWindowHour) {
		this.firstWindowHour = firstWindowHour;
	}

	public Integer getLastWindowHour() {
		return lastWindowHour;
	}

	public void setLastWindowHour(Integer lastWindowHour) {
		this.lastWindowHour = lastWindowHour;
	}

	public Long getPrecallCallerId() {
		return precallCallerId;
	}

	public void setPrecallCallerId(Long precallCallerId) {
		this.precallCallerId = precallCallerId;
	}

	public Long getPrecallTransfer() {
		return precallTransfer;
	}

	public void setPrecallTransfer(Long precallTransfer) {
		this.precallTransfer = precallTransfer;
	}

	public String getElectroluxLocation() {
		return electroluxLocation;
	}

	public void setElectroluxLocation(String electroluxLocation) {
		this.electroluxLocation = electroluxLocation;
	}

	public String getWayfairLocation() {
		return wayfairLocation;
	}

	public void setWayfairLocation(String wayfairLocation) {
		this.wayfairLocation = wayfairLocation;
	}

	public String getFaltlLocation() {
		return faltlLocation;
	}

	public void setFaltlLocation(String faltlLocation) {
		this.faltlLocation = faltlLocation;
	}

	public String getCreateDate() {
		return createDate;
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	public String getCreateBy() {
		return createBy;
	}

	public void setCreateBy(String createBy) {
		this.createBy = createBy;
	}

	public String getModifyDate() {
		return modifyDate;
	}

	public void setModifyDate(String modifyDate) {
		this.modifyDate = modifyDate;
	}

	public String getModifyBy() {
		return modifyBy;
	}

	public void setModifyBy(String modifyBy) {
		this.modifyBy = modifyBy;
	}

}
