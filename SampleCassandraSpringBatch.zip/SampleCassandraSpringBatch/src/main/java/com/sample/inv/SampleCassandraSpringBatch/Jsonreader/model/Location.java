package com.sample.inv.SampleCassandraSpringBatch.Jsonreader.model;



import java.sql.Timestamp;

import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("T_Location")
public class Location {

	@PrimaryKey("LOCATION_SEQ")
	private Long locationSeq;

	@Column("LOCATION_CODE")
	private String locationCode;

	@Column("GE_CODE")
	private String geCode;

//	@Column("ACCT_CODE")
//	private String acctCode;

	@Column("CITY")
	private String city;

	@Column("STATE")
	private String state;

	@Column("ZIP_CODE")
	private String zipcode;

//	@Column("SEASONAL_MESSAGE")
//	private String seasonalMessage;

	@Column("TIME_ZONE")
	private String timezone;

	/*@Column("WINDOW_LENGTH")
	private String windowLength;

	@Column("USE_30MIN_WINDOW")
	private String use30minWindow;

	@Column("FIRST_WINDOW_HOUR")
	private String firstWindowHour;

	@Column("LAST_WINDOW_HOUR")
	private Integer lastWindowHour;

	@Column("PRECALL_CALLER_ID")
	private Long precallCallerId;

	@Column("PRECALL_TRANSFER")
	private Long precallTransfer;*/

	@Column("ELECTROLUX_LOCATION")
	private String electroluxLocation;

	@Column("WAYFAIR_LOCATION")
	private String wayfairLocation;

	@Column("FALT_LOCATION")
	private String faltlLocation;

	@Column("CREATE_DATE")
	private Timestamp createDate;

	@Column("CREATE_BY")
	private String createBy;

	@Column("MODIFY_DATE")
	private String modifyDate;

	@Column("MODIFY_BY")
	private Timestamp modifyBy;

	public Long getLocationSeq() {
		return locationSeq;
	}

	public void setLocationSeq(Long locationSeq) {
		this.locationSeq = locationSeq;
	}

	public String getLocationCode() {
		return locationCode;
	}

	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}

	public String getGeCode() {
		return geCode;
	}

	public void setGeCode(String geCode) {
		this.geCode = geCode;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	public String getTimezone() {
		return timezone;
	}

	public void setTimezone(String timezone) {
		this.timezone = timezone;
	}

	public String getElectroluxLocation() {
		return electroluxLocation;
	}

	public void setElectroluxLocation(String electroluxLocation) {
		this.electroluxLocation = electroluxLocation;
	}

	public String getWayfairLocation() {
		return wayfairLocation;
	}

	public void setWayfairLocation(String wayfairLocation) {
		this.wayfairLocation = wayfairLocation;
	}

	public String getFaltlLocation() {
		return faltlLocation;
	}

	public void setFaltlLocation(String faltlLocation) {
		this.faltlLocation = faltlLocation;
	}

	public Timestamp getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Timestamp createDate) {
		this.createDate = createDate;
	}

	public String getCreateBy() {
		return createBy;
	}

	public void setCreateBy(String createBy) {
		this.createBy = createBy;
	}

	public String getModifyDate() {
		return modifyDate;
	}

	public void setModifyDate(String modifyDate) {
		this.modifyDate = modifyDate;
	}

	public Timestamp getModifyBy() {
		return modifyBy;
	}

	public void setModifyBy(Timestamp modifyBy) {
		this.modifyBy = modifyBy;
	}

	@Override
	public String toString() {
		return "Location [locationSeq=" + locationSeq + ", locationCode=" + locationCode + ", geCode=" + geCode
				+ ", city=" + city + ", state=" + state + ", zipcode=" + zipcode + ", timezone=" + timezone
				+ ", electroluxLocation=" + electroluxLocation + ", wayfairLocation=" + wayfairLocation
				+ ", faltlLocation=" + faltlLocation + ", createDate=" + createDate + ", createBy=" + createBy
				+ ", modifyDate=" + modifyDate + ", modifyBy=" + modifyBy + "]";
	}

	
}
