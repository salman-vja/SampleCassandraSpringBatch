package com.sample.inv.SampleCassandraSpringBatch.Jsonreader.reader;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.map.DeserializationConfig;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.type.TypeFactory;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.file.ResourceAwareItemReaderItemStream;
import org.springframework.batch.item.support.AbstractItemCountingItemStreamItemReader;
import org.springframework.core.io.Resource;
import org.springframework.util.Assert;
import org.springframework.util.ClassUtils;

import com.sample.inv.SampleCassandraSpringBatch.Jsonreader.dto.RouteDto;

import java.util.List;

@SuppressWarnings("rawtypes")
public class SampleCassandraBatchJsonReader extends AbstractItemCountingItemStreamItemReader implements ResourceAwareItemReaderItemStream {

	private static final Log logger = LogFactory.getLog(this.class);

	private Resource resource;

	private List<RouteDto> items;
	private String classToBound;
	private int index = 0;
	
	
	ObjectMapper mapper = new ObjectMapper();


	public void setClassToBound(String classToBound) {
		this.classToBound = classToBound;
	}

	public SampleCassandraBatchJsonReader() {
		setName(ClassUtils.getShortName(this.class));
	}

	public void setResource(Resource resource)
	{
			this.resource=resource;
	}

	@Override
	protected Object doRead() throws Exception
	{
		return (this.items == null  || index >= this.items.get(0).getData().size()) ? null : this.items.get(0).getData().get(index++);
	}

	@Override
	protected void doOpen() throws Exception
	{
		Assert.notNull(resource, "Input resource must be set");

		if (!resource.exists()) {
			logger.warn("Input resource does not exist " + resource.getDescription());
			return;
		}

		if (!resource.isReadable()) {
			logger.warn("Input resource is not readable " + resource.getDescription());
			return;
		}

		try {
			this.mapper.enable(DeserializationConfig.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY);
			this.items = this.mapper.readValue(resource.getInputStream(),
				TypeFactory.defaultInstance().constructCollectionType(List.class, Class.forName(this.classToBound)));
		}
		catch (Exception ex) {
			throw new ParseException("Parsing error", ex);
		}

	}

	@Override
	protected void doClose() throws Exception
	{
		// TODO Auto-generated method stub
	}

}
