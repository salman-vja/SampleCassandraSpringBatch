package com.sample.inv.SampleCassandraSpringBatch.Jsonreader;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.BeanUtils;

import com.sample.inv.SampleCassandraSpringBatch.Jsonreader.dto.LocationDataDto;
import com.sample.inv.SampleCassandraSpringBatch.Jsonreader.model.Location;

public class SampleCassandraBatchLocationJsonProcessor implements ItemProcessor<LocationDataDto, Location> {

	public Location process(final LocationDataDto locationDataEnity) throws Exception {
		Location locationDTO = new Location();
		BeanUtils.copyProperties(locationDataEnity, locationDTO);
		return locationDTO;
	}

}