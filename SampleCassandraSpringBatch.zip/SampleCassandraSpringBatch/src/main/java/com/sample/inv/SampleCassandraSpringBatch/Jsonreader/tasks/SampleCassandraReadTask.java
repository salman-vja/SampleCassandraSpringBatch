package com.sample.inv.SampleCassandraSpringBatch.tasks;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.sample.inv.SampleCassandraSpringBatch.tasks.constants.TaskConstants.PROXY_API_KEY;
import static com.sample.inv.SampleCassandraSpringBatch.tasks.constants.TaskConstants.PROXY_REBOUND_KEY;
import static com.sample.inv.SampleCassandraSpringBatch.tasks.constants.TaskConstants.PROXY_TOKEN_KEY;
import static com.sample.inv.SampleCassandraSpringBatch.tasks.constants.TaskConstants.PROXY_VERSION_KEY;
import static com.sample.inv.SampleCassandraSpringBatch.tasks.constants.TaskConstants.PROXY_API_VALUE;
import static com.sample.inv.SampleCassandraSpringBatch.tasks.constants.TaskConstants.PROXY_LOCATION_API_VALUE;
import static com.sample.inv.SampleCassandraSpringBatch.tasks.constants.TaskConstants.SER_URL;
import static com.sample.inv.SampleCassandraSpringBatch.tasks.constants.TaskConstants.PROXY_TOKEN_VAL;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.sample.inv.SampleCassandraSpringBatch.Jsonreader.dto.LocationDataDto;
import com.sample.inv.SampleCassandraSpringBatch.Jsonreader.dto.LocationDto;
import com.sample.inv.SampleCassandraSpringBatch.Jsonreader.dto.RouteDataDto;
import com.sample.inv.SampleCassandraSpringBatch.Jsonreader.dto.RouteDto;
import com.sample.inv.SampleCassandraSpringBatch.Jsonreader.model.Location;

public class SampleCassandraReadTask implements Tasklet, StepExecutionListener, Serializable {

	private static final long serialVersionUID = -6675373309880075936L;

	private List<LocationDataDto> locations;

	private List<RouteDataDto> todayRoutes;

	private List<RouteDataDto> tomorrowRoutes;

	@Value("${ReadTask.RoutesUrl}")
	private String routeUrl;

	@Value("${ReadTask.ProxyToken}")
	private String proxyToken;

	private static final Logger LOGGER = LogManager.getLogger(this.class);

	public ExitStatus afterStep(StepExecution stepExecution) {
		stepExecution.getJobExecution().getExecutionContext().put("OMSLocationData", this.locations);
		stepExecution.getJobExecution().getExecutionContext().put("OMSRouteData", this.todayRoutes);
		stepExecution.getJobExecution().getExecutionContext().put("OMSTomorrowRouteData", this.tomorrowRoutes);
		return null;
	}

	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

		LOGGER.info("Fetching Location data from OMS API...");

		ResponseEntity<LocationDto> locationResponse = getLocationData();
		if (null != locationResponse.getBody() && locationResponse.hasBody()) {
			this.locations = new ArrayList<>(locationResponse.getBody().getData());
			for (LocationDataDto location : locationResponse.getBody().getData()) {
			
				LOGGER.info("Calling Route API data for location Seq {} and DeliveryDate {}...", location.getLocationSeq(),
							LocalDate.now().plusDays(1).toString());
			
				this.todayRoutes = callRouteAPI(location.getLocationSeq(), LocalDate.now().plusDays(1).toString());
			
				LOGGER.info("Calling Route API data for location Seq {} and DeliveryDate {}...", location.getLocationSeq(),
							LocalDate.now().plusDays(2).toString());
			
				this.tomorrowRoutes = callRouteAPI(location.getLocationSeq(), LocalDate.now().plusDays(2).toString());
	    	}
		}
		if ((!this.todayRoutes.isEmpty()) && (!this.locations.isEmpty())) {
			return RepeatStatus.FINISHED;
		}
		return RepeatStatus.CONTINUABLE;
	}

	private List<RouteDataDto> callRouteAPI(long locationSeqNo, String deliveryDate) {
		List<RouteDataDto> routes = new ArrayList<>();
		ResponseEntity<RouteDto> routeResponse = getRouteData(locationSeqNo, deliveryDate);

		if (null != routeResponse.getBody() && routeResponse.hasBody()) {
			routes = new ArrayList<>(routeResponse.getBody().getData());
		}
		return routes;
	}

	public ResponseEntity<RouteDto> getRouteData(long locationSeqNumber, String deliveryDate) {
		RestTemplate restTemplate = new RestTemplate();
		ObjectMapper obj = new ObjectMapper();
		String proxyUrl = getProxyAPI(locationSeqNumber, deliveryDate);
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
			Map<String, String> parametersMap = new HashMap<>();
			parametersMap.put(PROXY_TOKEN_KEY, PROXY_TOKEN_VAL);
			parametersMap.put(PROXY_API_KEY, proxyUrl);
			parametersMap.put(PROXY_VERSION_KEY, "1.0");
			parametersMap.put(PROXY_REBOUND_KEY, "N");
			String requestBody = getDataString(parametersMap);
			HttpEntity<String> entity = new HttpEntity<>(requestBody, headers);
			String response="{\r\n" + 
					"    \"ReturnCode\": \"Success\",\r\n" + 
					"    \"data\": [\r\n" + 
					"        {\r\n" + 
					"            \"BatchRouteSeq\": \"781268\",\r\n" + 
					"            \"StartTime\": \"07:00:00\",\r\n" + 
					"            \"EndTime\": \"18:36:00\",\r\n" + 
					"            \"Duration\": \"11:36:00\",\r\n" + 
					"            \"RouteMileage\": \"131.70\",\r\n" + 
					"            \"StopSeq\": \"11687708\",\r\n" + 
					"            \"StopNumber\": \"1\",\r\n" + 
					"            \"EstimatedArrival\": \"08:12:00\",\r\n" + 
					"            \"EstimatedTime\": \"00:05:00\",\r\n" + 
					"            \"Latitude\": \"32.205\",\r\n" + 
					"            \"Longitude\": \"80.7041\",\r\n" + 
					"            \"StopMileage\": \"4.50\",\r\n" + 
					"            \"AutoTimeframeStart\": \"07:30:00\",\r\n" + 
					"            \"AutoTimeframeEnd\": \"11:30:00\",\r\n" + 
					"            \"EditTimeframeStart\": \"08:00:00\",\r\n" + 
					"            \"EditTimeframeEnd\": \"12:00:00\",\r\n" + 
					"            \"StopStatus\": \"NORMAL\",\r\n" + 
					"            \"DeliverySeq\": \"2388157\",\r\n" + 
					"            \"ChannelSeq\": \"3\",\r\n" + 
					"            \"RouteFlag\": \"Y\",\r\n" + 
					"            \"PrecallFlag\": \"N\",\r\n" + 
					"            \"PrecallStatus\": \"C\",\r\n" + 
					"            \"PrecallContactNumber\": \"\",\r\n" + 
					"            \"PrecallContactDatetime\": null,\r\n" + 
					"            \"CustSalesOrder\": \"13FS044026\",\r\n" + 
					"            \"OrderType\": \"Standard Sales\",\r\n" + 
					"            \"OrderDate\": \"2020-06-25\",\r\n" + 
					"            \"DeliveryId\": \"13ES00179585\",\r\n" + 
					"            \"ZipGroup\": \"EVERYDAY\",\r\n" + 
					"            \"DeliveryDate\": \"2020-07-01\",\r\n" + 
					"            \"DeliveryName\": \"BILLY WOOD APPLIANCE\",\r\n" + 
					"            \"DeliveryAddress1\": \"ATTN: MIKE HAERTEL\",\r\n" + 
					"            \"DeliveryAddress2\": \"6 MARSHLAND ROAD\",\r\n" + 
					"            \"DeliveryCity\": \"HILTON HEAD ISLA\",\r\n" + 
					"            \"DeliveryState\": \"SC\",\r\n" + 
					"            \"DeliveryZip\": \"29926\",\r\n" + 
					"            \"DeliveryPhone1\": \"(843)681-8441\",\r\n" + 
					"            \"DeliveryPhone2\": \"\",\r\n" + 
					"            \"DeliveryPhone3\": \"\",\r\n" + 
					"            \"DeliveryPhone4\": \"\",\r\n" + 
					"            \"LastUpdatedDate\": \"2020-06-29 00:00:00\",\r\n" + 
					"            \"CsoType\": \"BUILDER\",\r\n" + 
					"            \"CustomerPoNumber\": \"PO# 13624\",\r\n" + 
					"            \"Rap\": \"ZONE3\",\r\n" + 
					"            \"OrderPoints\": \"1.20\",\r\n" + 
					"            \"GeoStreet1\": \"ATTN  MIKE HAERTEL\",\r\n" + 
					"            \"GeoLatitude\": \"32.205\",\r\n" + 
					"            \"GeoLongitude\": \"-80.7041\",\r\n" + 
					"            \"DeliveryItemSeq\": \"11145481\",\r\n" + 
					"            \"LineNumber\": \"23.1\",\r\n" + 
					"            \"LineStatus\": \"CLOSED\",\r\n" + 
					"            \"CratedIndicator\": \"CRATED\",\r\n" + 
					"            \"ItemType\": \"M\",\r\n" + 
					"            \"Item\": \"GFD55ESPNDG\",\r\n" + 
					"            \"ProductType\": \"LAUNDRY\",\r\n" + 
					"            \"AntiTipIndicator\": \"\",\r\n" + 
					"            \"ProductWeight\": \"0.00\",\r\n" + 
					"            \"Nmfc\": \"0\",\r\n" + 
					"            \"CartonCode\": \"0\",\r\n" + 
					"            \"Quantity\": \"1\",\r\n" + 
					"            \"Points\": \"1.00\",\r\n" + 
					"            \"AssignedSerials\": \"FR198058\",\r\n" + 
					"            \"CustomerTrackingNumber\": \"13FS044026\",\r\n" + 
					"            \"ItemVendor\": \"GEA\",\r\n" + 
					"            \"ItemShipdate\": \"2020-06-30\",\r\n" + 
					"            \"LocationSeq\": \"29\",\r\n" + 
					"            \"LocationCode\": \"13FS\",\r\n" + 
					"            \"GeCode\": \"3FS\",\r\n" + 
					"            \"DaySeq\": \"28835\",\r\n" + 
					"            \"DeliveryDay\": \"2020-07-01\",\r\n" + 
					"            \"RouteSeq\": \"1194\",\r\n" + 
					"            \"RouteName\": \"RT01\",\r\n" + 
					"            \"ShipmentSeq\": \"109627\",\r\n" + 
					"            \"Vendor\": \"GEA\",\r\n" + 
					"            \"ShipmentNumber\": \"13FS044049\",\r\n" + 
					"            \"ShipDate\": \"2020-06-30\",\r\n" + 
					"            \"ShipmentStatus\": \"\",\r\n" + 
					"            \"LstShipmentStatus\": \"\",\r\n" + 
					"            \"ChannelCode\": \"GESDS\",\r\n" + 
					"            \"DeliveryStatus\": \"Delivered\",\r\n" + 
					"            \"ComboGroup\": \"329140\",\r\n" + 
					"            \"Description\": null,\r\n" + 
					"            \"EluxLotId\": null\r\n" + 
					"        },\r\n" + 
					"        {\r\n" + 
					"            \"BatchRouteSeq\": \"783968\",\r\n" + 
					"            \"StartTime\": \"07:00:00\",\r\n" + 
					"            \"EndTime\": \"18:36:00\",\r\n" + 
					"            \"Duration\": \"11:36:00\",\r\n" + 
					"            \"RouteMileage\": \"131.70\",\r\n" + 
					"            \"StopSeq\": \"11687708\",\r\n" + 
					"            \"StopNumber\": \"1\",\r\n" + 
					"            \"EstimatedArrival\": \"08:12:00\",\r\n" + 
					"            \"EstimatedTime\": \"00:05:00\",\r\n" + 
					"            \"Latitude\": \"32.205\",\r\n" + 
					"            \"Longitude\": \"80.7041\",\r\n" + 
					"            \"StopMileage\": \"4.50\",\r\n" + 
					"            \"AutoTimeframeStart\": \"07:30:00\",\r\n" + 
					"            \"AutoTimeframeEnd\": \"11:30:00\",\r\n" + 
					"            \"EditTimeframeStart\": \"08:00:00\",\r\n" + 
					"            \"EditTimeframeEnd\": \"12:00:00\",\r\n" + 
					"            \"StopStatus\": \"NORMAL\",\r\n" + 
					"            \"DeliverySeq\": \"2388157\",\r\n" + 
					"            \"ChannelSeq\": \"3\",\r\n" + 
					"            \"RouteFlag\": \"Y\",\r\n" + 
					"            \"PrecallFlag\": \"N\",\r\n" + 
					"            \"PrecallStatus\": \"C\",\r\n" + 
					"            \"PrecallContactNumber\": \"\",\r\n" + 
					"            \"PrecallContactDatetime\": null,\r\n" + 
					"            \"CustSalesOrder\": \"13FS044026\",\r\n" + 
					"            \"OrderType\": \"Standard Sales\",\r\n" + 
					"            \"OrderDate\": \"2020-06-25\",\r\n" + 
					"            \"DeliveryId\": \"13BS00179585\",\r\n" + 
					"            \"ZipGroup\": \"EVERYDAY\",\r\n" + 
					"            \"DeliveryDate\": \"2020-07-01\",\r\n" + 
					"            \"DeliveryName\": \"BILLY WOOD APPLIANCE\",\r\n" + 
					"            \"DeliveryAddress1\": \"ATTN: MIKE HAERTEL\",\r\n" + 
					"            \"DeliveryAddress2\": \"6 MARSHLAND ROAD\",\r\n" + 
					"            \"DeliveryCity\": \"HILTON HEAD ISLA\",\r\n" + 
					"            \"DeliveryState\": \"SC\",\r\n" + 
					"            \"DeliveryZip\": \"29926\",\r\n" + 
					"            \"DeliveryPhone1\": \"(843)681-8441\",\r\n" + 
					"            \"DeliveryPhone2\": \"\",\r\n" + 
					"            \"DeliveryPhone3\": \"\",\r\n" + 
					"            \"DeliveryPhone4\": \"\",\r\n" + 
					"            \"LastUpdatedDate\": \"2020-06-29 00:00:00\",\r\n" + 
					"            \"CsoType\": \"BUILDER\",\r\n" + 
					"            \"CustomerPoNumber\": \"PO# 13624\",\r\n" + 
					"            \"Rap\": \"ZONE3\",\r\n" + 
					"            \"OrderPoints\": \"1.20\",\r\n" + 
					"            \"GeoStreet1\": \"ATTN  MIKE HAERTEL\",\r\n" + 
					"            \"GeoLatitude\": \"32.205\",\r\n" + 
					"            \"GeoLongitude\": \"-80.7041\",\r\n" + 
					"            \"DeliveryItemSeq\": \"11162500\",\r\n" + 
					"            \"LineNumber\": \"26.1\",\r\n" + 
					"            \"LineStatus\": \"CLOSED\",\r\n" + 
					"            \"CratedIndicator\": \"\",\r\n" + 
					"            \"ItemType\": \"S\",\r\n" + 
					"            \"Item\": \"M996\",\r\n" + 
					"            \"ProductType\": \"MINIMUM DELIVERY\",\r\n" + 
					"            \"AntiTipIndicator\": \"\",\r\n" + 
					"            \"ProductWeight\": \"0.00\",\r\n" + 
					"            \"Nmfc\": \"0\",\r\n" + 
					"            \"CartonCode\": \"0\",\r\n" + 
					"            \"Quantity\": \"0\",\r\n" + 
					"            \"Points\": \"0.00\",\r\n" + 
					"            \"AssignedSerials\": null,\r\n" + 
					"            \"CustomerTrackingNumber\": \"\",\r\n" + 
					"            \"ItemVendor\": \"\",\r\n" + 
					"            \"ItemShipdate\": null,\r\n" + 
					"            \"LocationSeq\": \"29\",\r\n" + 
					"            \"LocationCode\": \"13FS\",\r\n" + 
					"            \"GeCode\": \"3FS\",\r\n" + 
					"            \"DaySeq\": \"28835\",\r\n" + 
					"            \"DeliveryDay\": \"2020-07-01\",\r\n" + 
					"            \"RouteSeq\": \"1194\",\r\n" + 
					"            \"RouteName\": \"RT01\",\r\n" + 
					"            \"ShipmentSeq\": null,\r\n" + 
					"            \"Vendor\": null,\r\n" + 
					"            \"ShipmentNumber\": 9876567,\r\n" + 
					"            \"ShipDate\": null,\r\n" + 
					"            \"ShipmentStatus\": null,\r\n" + 
					"            \"LstShipmentStatus\": null,\r\n" + 
					"            \"ChannelCode\": \"GESDS\",\r\n" + 
					"            \"DeliveryStatus\": \"Delivered\",\r\n" + 
					"            \"ComboGroup\": \"329140\",\r\n" + 
					"            \"Description\": null,\r\n" + 
					"            \"EluxLotId\": null\r\n" + 
					"        }\r\n" + 
					"	]\r\n" + 
					"}";
			ResponseEntity<String> responseBody = new ResponseEntity(response,HttpStatus.OK);
					//restTemplate.postForEntity(SER_URL, entity, String.class);
			//ResponseEntity<String> responseBody = restTemplate.postForEntity(SER_URL, entity, String.class);
			if (responseBody.hasBody() && responseBody.getStatusCode().equals(HttpStatus.OK)) {
				RouteDto routeEntity = obj.readValue(responseBody.getBody(), RouteDto.class);
				return new ResponseEntity<>(routeEntity, HttpStatus.OK);
			} else {
				LOGGER.info("No Route data  found for location Seq {} and DeliveryDate {} ..", locationSeqNumber,deliveryDate);
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}

		} catch (Exception e) {
			LOGGER.info("Fetching Route data  failed for location Seq {} and DeliveryDate {} with exception: {}", locationSeqNumber,deliveryDate,e);
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	private String getProxyAPI(long locationSeqNumber, String deliveryDate) {
		return PROXY_API_VALUE + locationSeqNumber + "/" + deliveryDate;
	}

	public ResponseEntity<LocationDto> getLocationData() {
		RestTemplate restTemplate = new RestTemplate();
		ObjectMapper obj = new ObjectMapper();
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
			Map<String, String> parametersMap = new HashMap<>();
			parametersMap.put(PROXY_TOKEN_KEY, PROXY_TOKEN_VAL);
			parametersMap.put(PROXY_API_KEY, PROXY_LOCATION_API_VALUE);
			parametersMap.put(PROXY_VERSION_KEY, "1.0");
			parametersMap.put(PROXY_REBOUND_KEY, "N");
			String requestBody = getDataString(parametersMap);
			HttpEntity<String> entity = new HttpEntity<>(requestBody, headers);
			String response="{\r\n" + 
					"    \"ReturnCode\": \"Success\",\r\n" + 
					"    \"data\": [\r\n" + 
					"        {\r\n" + 
					"            \"LocationSeq\": \"1268\",\r\n" + 
					"            \"LocationCode\": \"112L\",\r\n" + 
					"            \"GeCode\": \"62L\",\r\n" + 
					"            \"AcctCode\": \"\",\r\n" + 
					"            \"City\": \"Omaha\",\r\n" + 
					"            \"State\": \"NE\",\r\n" + 
					"            \"Zipcode\": \"99999-9999\",\r\n" + 
					"            \"SeasonalMessage\": \"N\",\r\n" + 
					"            \"Timezone\": \"Central\",\r\n" + 
					"            \"WindowLength\": \"4\",\r\n" + 
					"            \"Use30minWindow\": \"Y\",\r\n" + 
					"            \"FirstWindowHour\": \"7\",\r\n" + 
					"            \"LastWindowHour\": \"19\",\r\n" + 
					"            \"PrecallCallerId\": \"8008566508\",\r\n" + 
					"            \"PrecallTransfer\": \"8008566508\",\r\n" + 
					"            \"ElectroluxLocation\": \"\",\r\n" + 
					"            \"WayfairLocation\": \"\",\r\n" + 
					"            \"FaltlLocation\": \"\",\r\n" + 
					"            \"CreateDate\": \"2017-03-05 20:42:21\",\r\n" + 
					"            \"CreateBy\": \"bellagio@localhost\",\r\n" + 
					"            \"ModifyDate\": \"2020-04-30 08:15:06\",\r\n" + 
					"            \"ModifyBy\": \"bellagio@localhost\"\r\n" + 
					"        },\r\n" + 
					"        {\r\n" + 
					"            \"LocationSeq\": \"6678\",\r\n" + 
					"            \"LocationCode\": \"126C\",\r\n" + 
					"            \"GeCode\": \"66C\",\r\n" + 
					"            \"AcctCode\": \"\",\r\n" + 
					"            \"City\": \"Minneapolis\",\r\n" + 
					"            \"State\": \"MN\",\r\n" + 
					"            \"Zipcode\": \"99999-9999\",\r\n" + 
					"            \"SeasonalMessage\": \"N\",\r\n" + 
					"            \"Timezone\": \"Central\",\r\n" + 
					"            \"WindowLength\": \"4\",\r\n" + 
					"            \"Use30minWindow\": \"Y\",\r\n" + 
					"            \"FirstWindowHour\": \"7\",\r\n" + 
					"            \"LastWindowHour\": \"19\",\r\n" + 
					"            \"PrecallCallerId\": \"8008566508\",\r\n" + 
					"            \"PrecallTransfer\": \"8008566508\",\r\n" + 
					"            \"ElectroluxLocation\": \"\",\r\n" + 
					"            \"WayfairLocation\": \"\",\r\n" + 
					"            \"FaltlLocation\": \"\",\r\n" + 
					"            \"CreateDate\": \"2017-03-05 20:42:21\",\r\n" + 
					"            \"CreateBy\": \"bellagio@localhost\",\r\n" + 
					"            \"ModifyDate\": \"2020-04-30 08:15:08\",\r\n" + 
					"            \"ModifyBy\": \"bellagio@localhost\"\r\n" + 
					"        },\r\n" + 
					"        {\r\n" + 
					"            \"LocationSeq\": \"4490\",\r\n" + 
					"            \"LocationCode\": \"126H\",\r\n" + 
					"            \"GeCode\": \"66H\",\r\n" + 
					"            \"AcctCode\": \"\",\r\n" + 
					"            \"City\": \"Cedar Rapids\",\r\n" + 
					"            \"State\": \"IA\",\r\n" + 
					"            \"Zipcode\": \"99999-9999\",\r\n" + 
					"            \"SeasonalMessage\": \"N\",\r\n" + 
					"            \"Timezone\": \"Central\",\r\n" + 
					"            \"WindowLength\": \"4\",\r\n" + 
					"            \"Use30minWindow\": \"Y\",\r\n" + 
					"            \"FirstWindowHour\": \"7\",\r\n" + 
					"            \"LastWindowHour\": \"19\",\r\n" + 
					"            \"PrecallCallerId\": \"8008566508\",\r\n" + 
					"            \"PrecallTransfer\": \"8008566508\",\r\n" + 
					"            \"ElectroluxLocation\": \"\",\r\n" + 
					"            \"WayfairLocation\": \"\",\r\n" + 
					"            \"FaltlLocation\": \"\",\r\n" + 
					"            \"CreateDate\": \"2017-03-05 20:42:21\",\r\n" + 
					"            \"CreateBy\": \"bellagio@localhost\",\r\n" + 
					"            \"ModifyDate\": \"2020-04-30 08:15:11\",\r\n" + 
					"            \"ModifyBy\": \"bellagio@localhost\"\r\n" + 
					"        }\r\n" + 
					"	]\r\n" + 
					"}";
			ResponseEntity<String> responseBody = new ResponseEntity(response,HttpStatus.OK); 
					//restTemplate.postForEntity(SER_URL, entity, String.class);
			//ResponseEntity<String> responseBody = restTemplate.postForEntity(SER_URL, entity, String.class);
			if (responseBody.hasBody() && responseBody.getStatusCode().equals(HttpStatus.OK)) {
				LocationDto locationDto = obj.readValue(responseBody.getBody(), LocationDto.class);
				return new ResponseEntity<>(locationDto, HttpStatus.OK);
			} else {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}

		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	private String getDataString(Map<String, String> params) {
		StringBuilder result = new StringBuilder();
		boolean first = true;
		for (Map.Entry<String, String> entry : params.entrySet()) {
			if (first)
				first = false;
			else
				result.append("&");
			result.append(entry.getKey());
			result.append("=");
			result.append(entry.getValue());
		}
		return result.toString();
	}

	@Override
	public void beforeStep(StepExecution stepExecution) {
		// TODO Auto-generated method stub

	}

}
