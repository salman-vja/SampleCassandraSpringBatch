package com.sample.inv.SampleCassandraSpringBatch.Jsonreader;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.cassandra.core.CassandraTemplate;

import com.sample.inv.SampleCassandraSpringBatch.Jsonreader.model.Location;

public class SampleCassandraBatchLocationJsonWriter implements ItemWriter<Location> {

	private static final Log logger = LogFactory.getLog(this.class);

	@Autowired
	private CassandraTemplate cassandraTemplate;

	public void write(List<? extends Location> items) throws Exception {

		long recordCount = cassandraTemplate.count(Location.class);
		for (Location item : items) {
			if (recordCount > 0) {
				if (items.size() > recordCount) {

					if (cassandraTemplate.exists(item.getLocationSeq(), Location.class)) {
						cassandraTemplate.update(item);
					} else {
						cassandraTemplate.insert(item);
					}

				} else if (items.size() < recordCount) {

					if (cassandraTemplate.exists(item.getLocationSeq(), Location.class)) {
						cassandraTemplate.update(item);
					} else {
						boolean flag = cassandraTemplate.deleteById(item.getLocationSeq(), Location.class);
						if (!flag) {
							cassandraTemplate.insert(item);
						} else
							continue;
					}

				}else {
					cassandraTemplate.update(item);
				}
			} else
				cassandraTemplate.insert(item);
		}

		logger.info("Total Records persisted in t_location table:: " + cassandraTemplate.count(Location.class));
	}

}
