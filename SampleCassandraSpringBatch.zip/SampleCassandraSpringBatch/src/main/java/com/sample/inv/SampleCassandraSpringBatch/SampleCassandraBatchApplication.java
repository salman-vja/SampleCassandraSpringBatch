package com.sample.inv.SampleCassandraSpringBatch;

import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;

import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import org.springframework.context.annotation.Import;


@SpringBootApplication
@EnableBatchProcessing
public class SampleCassandraBatchApplication implements CommandLineRunner {
    

    public static void main(final String[] args) {

        SpringApplication.run(SampleCassandraBatchApplication.class, args);
    }

    @Override
    public void run(final String... strings) throws Exception {
        
    }
}
