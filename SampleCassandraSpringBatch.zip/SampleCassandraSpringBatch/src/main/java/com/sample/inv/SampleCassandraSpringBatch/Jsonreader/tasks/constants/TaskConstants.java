package com.sample.inv.SampleCassandraSpringBatch.tasks.constants;

public class TaskConstants {
	
	public  static String PROXY_TOKEN_KEY="BE_PROXY_TOKEN";
	public  static String PROXY_API_KEY="BE_PROXY_API";
	public static String PROXY_VERSION_KEY="BE_PROXY_VERSION";
	public static String PROXY_REBOUND_KEY="BE_PROXY_REBOUND";
	public static String PROXY_API_VALUE="/rest/api/routes_view/location/";
	public static String PROXY_LOCATION_API_VALUE="/rest/api/location";
	public static String PROXY_TOKEN_VAL="theworldisflatasaboatfallsoftheedgeoftheearthandfalls481928feet";
	public static String SER_URL="https://lsterp-stg.icdesigns.com/beproxy.php";
	public static String CREATED_BY="SampleCassandraSpringBatch";
	

}
