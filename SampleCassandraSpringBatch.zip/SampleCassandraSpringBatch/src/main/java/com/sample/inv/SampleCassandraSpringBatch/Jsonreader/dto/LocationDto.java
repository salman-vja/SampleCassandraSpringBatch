package com.sample.inv.SampleCassandraSpringBatch.Jsonreader.dto;


import java.io.Serializable;
import java.util.List;

import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.map.annotate.JsonSerialize;


@JsonSerialize
public class LocationDto implements Serializable{

	private static final long serialVersionUID = -4768395625787010658L;

	@JsonProperty("ReturnCode")
	public String returnCode;

	@JsonProperty("data")
	 public List<LocationDataDto> data;

	public LocationDto() {
		super();
	}

	public LocationDto(String returnCode, List<LocationDataDto> data) {
		super();
		this.returnCode = returnCode;
		this.data = data;
	}

	public String getReturnCode()
	{
		return returnCode;
	}

	public void setReturnCode(String returnCode)
	{
		this.returnCode = returnCode;
	}

	public List<LocationDataDto> getData()
	{
		return data;
	}

	public void setData(List<LocationDataDto> data)
	{
		this.data = data;
	}

	@Override
	public String toString()
	{
		return "LocationEntity [returnCode=" + returnCode + ", data=" + data + "]";
	}






}
